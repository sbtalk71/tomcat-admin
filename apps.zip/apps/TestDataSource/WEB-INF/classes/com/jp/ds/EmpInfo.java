package com.jp.ds;

import java.io.*;
import java.sql.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.sql.DataSource;

public class EmpInfo extends HttpServlet
{

    Connection con;
    Statement st;
    ResultSet rs;
	 DataSource ds;
    int id;

    public EmpInfo()
    {
    }

    public void init(ServletConfig config)
        throws ServletException
    {
        super.init(config);
        try
        {
            InitialContext ic = new InitialContext();
            Context env = (Context)ic.lookup("java:comp/env");
            ds = (DataSource)env.lookup("jdbc/ds");
            System.out.println(ds.getClass().getSimpleName());
             //System.out.println((new StringBuilder("Connection ")).append(con).toString());
           // System.out.println(":::::::::Connected:::::::::::");
        }
        catch(Exception se)
        {
            System.out.println("problem with connection establishment");
            se.printStackTrace();
        }
    }

    public void doGet(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        System.out.println("\n in the doGet ");
        System.out.println((new StringBuilder("Connection ")).append(con).toString());
        res.setContentType("text/plain");
        PrintWriter out = res.getWriter();
        id = Integer.parseInt(req.getParameter("no"));
        try
        {  con = ds.getConnection();
            st = con.createStatement();
            System.out.println((new StringBuilder("Statement =")).append(st).toString());
            for(ResultSet rs = st.executeQuery((new StringBuilder("select name,salary from MYEMP where empid=")).append(id).toString()); rs.next(); out.println((new StringBuilder("Salary : ")).append(rs.getDouble("salary")).toString()))
            {
                out.println((new StringBuilder("Employee No :")).append(id).toString());
                out.println((new StringBuilder("Name :")).append(rs.getString("name")).toString());
            }

            out.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            System.out.println((new StringBuilder("error while retrieving the data ")).append(e).toString());
        }
		finally{
			try{
				con.close();
			}
			catch(SQLException se){
				se.printStackTrace();
			}
		}
    }
}
